// Validate Contact Us Form
var form = document.querySelector('form');
form.addEventListener('submit', function(event) {

    event.preventDefault();
    validateFName(this.firstName.value);
    validateLName(this.lastName.value);
    validatePhone(this.phone.value);
    validateEmail(this.email.value);
});

// First Name
function validateFName(fname) {
    var fNameError = document.querySelector("#firstNameError");
    
    if (fname.length === 0) {
        fNameError.style.display = "block";
    }
    else {
        fNameError.style.display = "none";
    }
}

// Last Name
function validateLName(lname) {
    var lNameError = document.querySelector("#lastNameError");

    if (lname.length === 0) {
       lNameError.style.display = "block";
    }
    else {
        lNameError.style.display = "none";
    }
}

// Telephone
function validatePhone(phone) {
    var phoneError = document.querySelector("#phoneError");
    var phonePattern = /[0-9]{3}[\s\-\.][0-9]{3}[\s\-\.][0-9]{4}/;
    
    if (!phone.match(phonePattern)) {
        phoneError.style.display = "block";
    }
    else {
       phoneError.style.display = "none";
    }
}

//E-mail
function validateEmail(email) {
    var emailError = document.querySelector("#emailError");
    var emailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    
    if (!email.match(emailPattern)) {
        emailError.style.display = "block";
    }
    else {
        emailError.style.display = "none";
    }
}