// Replace Magic with Something
function repalaceFunction(x){
    var replaceMagic = x.replace(/magic/ig, "Something");
    return replaceMagic;
}

var aboutText = document.querySelector('#aboutText');
var text = aboutText.innerHTML;
aboutText.innerHTML = repalaceFunction(text);

// Display Hidden Content Block
var trigger = document.querySelector('#moreInfoTrigger');
var content = document.querySelector('#moreInfoContent');

trigger.addEventListener('click', function() {
    
    if(content.style.display === "none") {
        content.style.display = "block";
    }
    else {
        content.style.display = "none";
    }
});