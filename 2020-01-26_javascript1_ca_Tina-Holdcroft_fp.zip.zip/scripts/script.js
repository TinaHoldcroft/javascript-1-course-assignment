// Connect to API
fetch("https://api.magicthegathering.io/v1/cards")
	.then(function(convert) {
		return convert.json ()
	})
	.then(function(json) {
        cardCreator(json);
	})

function cardCreator(json) {
	var cardArray = json.cards;
    let newHTML = "";
    let imageUrl = "https://via.placeholder.com/223x310"; //Default image
	cardArray.forEach(function(card) {
    
        if(card.imageUrl) {
			imageUrl = card.imageUrl;
		}
		newHTML += `<div class="col-sm-4">
					    <div class="card-container">
						    <h4>${card.name}</h4>
						    <img src="${imageUrl}">
						    <a href="card-specific.html?id=${card.id}" class="btn btn-success">View More</a>
					    </div>
				    </div>`;
    })
    
	document.getElementById('cards').innerHTML = newHTML
}

//Search Box
var searchButton = document.querySelector('#searchButton');
searchButton.addEventListener('click', search);

function search() {
	var searchBox = document.querySelector('#search');
  	var searchValue = searchBox.value;
    fetch("https://api.magicthegathering.io/v1/cards")
        .then(function(convert) {
            return convert.json ()
        })
        .then(function(json) {
            filteredCardCreator(searchValue, json);
        })
}

function filteredCardCreator(searchValue, json) {    
	var cardArray = json.cards;
    let newHTMLfilter = "";

    var cardFilter = cardArray.filter(function(card) {
		if(card.name.toLowerCase().startsWith(searchValue.toLowerCase())) {
			return true
        }
    })

	cardFilter.forEach(function(card) {
		if(card.imageUrl) {
			imageUrl = card.imageUrl;
		}
		newHTMLfilter += `<div class="col-sm-4">
					        <div class="card-container">
						        <h4>${card.name}</h4>
						        <img src="${imageUrl}">
						        <a href="card-specific.html?id=${card.id}" class="btn btn-success">View More</a>
					        </div>
				          </div>`;
	})
    
    document.getElementById('cards').innerHTML = newHTMLfilter;
}