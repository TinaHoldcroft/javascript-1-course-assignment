// Get URL query string
function getQueryStringValue (key) {
    return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
}
// Variable for the ID
var ID = getQueryStringValue("ID");
var url = "https://api.magicthegathering.io/v1/cards/" + ID;

fetch(url)
    .then(function(convert) {
        return convert.json()
})
    .then(function(json) {
        cardGenerator(json);
});

function cardGenerator(json) {
    var card = json.card;
    let image = "No image";

    if(card.imageUrl) {
        image = `<img src="${card.imageUrl}">`;
    }

    let details = `<h2>${card.name}</h2>
                <div>
                    <b>About:</b> ${card.text}
                </div>
                <div> 
                    <b>Rarity:</b> ${card.rarity}
                </div>
                <div>
                    <b>Color:</b> ${card.colors.toString()}
                </div>`;

    console.log(json);
    document.getElementById('cardImage').innerHTML = image;
    document.getElementById('cardDetails').innerHTML = details;
}